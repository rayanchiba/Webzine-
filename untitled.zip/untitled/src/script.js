// سنة

document.getElementById('year').textContent = new Date().getFullYear();

// تفعيل تبويب الديمو في الصفحة الرئيسية

document.querySelectorAll('.chip').forEach(ch => {

  ch.addEventListener('click', () => {

    document.querySelectorAll('.chip').forEach(x => x.classList.remove('is-active'));

    ch.classList.add('is-active');

    const k = ch.dataset.demo;

    document.querySelectorAll('.demo__view').forEach(v => v.classList.remove('is-active'));

    document.getElementById('demo-' + k).classList.add('is-active');

  });

});

// تبديل الثيم

document.getElementById('btn-theme').addEventListener('click', () => {

  document.body.classList.toggle('theme-light');

  document.body.classList.toggle('theme-dark');

});

// تنقّل بين المشاهد

const views = {

  home: document.getElementById('view-home'),

  code: document.getElementById('view-code'),

  nocode: document.getElementById('view-nocode'),

};

function showView(name){

  Object.values(views).forEach(v => v.classList.remove('is-visible'));

  views[name].classList.add('is-visible');

  document.querySelectorAll('.nav__link').forEach(a => a.classList.toggle('is-active', a.dataset.view===name));

  window.scrollTo({ top: 0, behavior: 'smooth' });

}

// أزرار البدء

document.getElementById('btn-new').addEventListener('click', openModal);

document.getElementById('cta-new').addEventListener('click', openModal);

function openModal(){

  modal.classList.add('is-open');

  modal.setAttribute('aria-hidden','false');

  projectNameInput.focus();

}

const modal = document.getElementById('modal');

document.getElementById('modal-cancel').addEventListener('click', () => {

  modal.classList.remove('is-open');

  modal.setAttribute('aria-hidden','true');

});

// تهيئة نموذج مشروع جديد

const projectNameInput = document.getElementById('project-name-input');

const htmlFileInput = document.getElementById('html-file');

const uploadField = document.getElementById('upload-field');

const editorRadios = Array.from(document.querySelectorAll('input[name="editor"]'));

editorRadios.forEach(r => {

  r.addEventListener('change', () => {

    uploadField.hidden = r.value !== 'code';

  });

});

document.getElementById('modal-create').addEventListener('click', async () => {

  const name = (projectNameInput.value || '').trim() || 'مشروعي';

  const type = (editorRadios.find(r => r.checked) || {}).value;

  if(!type){ alert('اختر نوع المحرر.'); return; }

  // حفظ بيانات المشروع الحالية

  localStorage.setItem('currentProject', JSON.stringify({ name, type, ts: Date.now() }));

  // إذا رُفع ملف HTML، حمّله في محرر الكود

  if(type === 'code' && htmlFileInput.files[0]){

    const file = htmlFileInput.files[0];

    const text = await file.text();

    document.getElementById('html-code').value = text;

  }

  // تحديث أسماء المشاريع في العناوين

  document.getElementById('project-name-code').textContent = name;

  document.getElementById('project-name-nocode').textContent = name;

  // إغلاق المودال والانتقال

  modal.classList.remove('is-open');

  modal.setAttribute('aria-hidden','true');

  showView(type === 'code' ? 'code' : 'nocode');

  // بناء المعاينة الأولية للكود

  if(type==='code') buildPreview();

});

// تحميل مشروع محفوظ إن وجد

window.addEventListener('load', () => {

  const raw = localStorage.getItem('currentProject');

  if(raw){

    const { name, type } = JSON.parse(raw);

    if(name){

      document.getElementById('project-name-code').textContent = name;

      document.getElementById('project-name-nocode').textContent = name;

    }

  }

  // افتراضيًا إظهار الرئيسية

  showView('home');

});

/* ===================== محرر الكود ===================== */

const htmlCode = document.getElementById('html-code');

const cssCode  = document.getElementById('css-code');

const jsCode   = document.getElementById('js-code');

const preview  = document.getElementById('preview');

function buildPreview(){

  const html = htmlCode.value || '';

  const css  = cssCode.value  || '';

  const js   = jsCode.value   || '';

  const doc = `

<!doctype html><html lang="ar" dir="rtl"><head>

<meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>

<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src https: data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; font-src https: data:;">

<style>${css}</style></head><body>${html}

<script>${js}<\/script></body></html>`;

  preview.srcdoc = doc;

}

[htmlCode, cssCode, jsCode].forEach(t => t.addEventListener('input', buildPreview));

// استيراد HTML

document.getElementById('import-html').addEventListener('change', async (e) => {

  const f = e.target.files[0]; if(!f) return;

  const txt = await f.text();

  htmlCode.value = txt;

  buildPreview();

});

// حفظ وتصدير (كود)

document.getElementById('save-code').addEventListener('click', () => {

  const key = 'project-code';

  localStorage.setItem(key, JSON.stringify({

    html: htmlCode.value, css: cssCode.value, js: jsCode.value, t: Date.now()

  }));

  alert('تم الحفظ محليًا.');

});

document.getElementById('export-code').addEventListener('click', () => {

  const content = exportSingleHTML(htmlCode.value, cssCode.value, jsCode.value);

  download('project-code.html', content, 'text/html');

});

function exportSingleHTML(html, css, js){

  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><title>مشروعي</title><style>${css||''}</style></head><body>${html||''}<script>${js||''}<\/script></body></html>`;

}

/* ===================== محرر بدون كود ===================== */

const canvas = document.getElementById('canvas');

const tools = Array.from(document.querySelectorAll('.tool'));

const propText   = document.getElementById('prop-text');

const propFont   = document.getElementById('prop-font');

const propColor  = document.getElementById('prop-color');

const propBg     = document.getElementById('prop-bg');

const propRadius = document.getElementById('prop-radius');

const propLink   = document.getElementById('prop-link');

let selected = null;

let zoom = 1;

tools.forEach(btn => btn.addEventListener('click', () => addNode(btn.dataset.type)));

canvas.addEventListener('dblclick', (e) => {

  // إضافة نص بسرعة بالنقرة المزدوجة

  const rect = canvas.getBoundingClientRect();

  addNode('text', e.clientX - rect.left, e.clientY - rect.top);

});

function addNode(type, x = 120, y = 120){

  const el = document.createElement('div');

  el.className = 'node';

  el.style.left = Math.max(24, x) + 'px';

  el.style.top  = Math.max(24, y) + 'px';

  el.style.minWidth = '60px';

  el.style.minHeight = '40px';

  el.tabIndex = 0;

  let inner;

  if(type==='text'){ inner = document.createElement('div'); inner.textContent='نص'; inner.contentEditable=true; inner.style.padding='8px'; inner.style.fontSize='18px'; }

  if(type==='button'){ inner = document.createElement('a'); inner.href='#'; inner.textContent='زر'; inner.style.display='inline-block'; inner.style.padding='10px 14px'; inner.style.background='var(--accent)'; inner.style.color='var(--accent-ink)'; inner.style.borderRadius='10px'; }

  if(type==='image'){ inner = document.createElement('img'); inner.src='https://picsum.photos/seed/site/420/240'; inner.style.display='block'; inner.style.width='240px'; inner.style.height='auto'; el.style.minWidth='0'; el.style.minHeight='0'; }

  if(type==='box'){ inner = document.createElement('div'); inner.style.width='180px'; inner.style.height='120px'; inner.style.background='#0f172a'; inner.style.border='1px solid var(--border)'; inner.style.borderRadius='10px'; }

  if(!inner) return;

  el.appendChild(inner);

  const handle = document.createElement('div');

  handle.className = 'handle';

  el.appendChild(handle);

  // سحب وتحريك

  let dragging=false, ox=0, oy=0;

  el.addEventListener('pointerdown', (ev) => {

    if(ev.target===handle) return;

    dragging=true; const r = el.getBoundingClientRect(); ox = ev.clientX - r.left; oy = ev.clientY - r.top;

    el.setPointerCapture(ev.pointerId);

    selectNode(el);

  });

  el.addEventListener('pointermove', (ev) => {

    if(!dragging) return;

    const rect = canvas.getBoundingClientRect();

    const nx = (ev.clientX - rect.left - ox);

    const ny = (ev.clientY - rect.top  - oy);

    el.style.left = snap(nx / zoom) + 'px';

    el.style.top  = snap(ny / zoom) + 'px';

  });

  el.addEventListener('pointerup', () => dragging=false);

  // تغيير الحجم

  let resizing=false, sx=0, sy=0, sw=0, sh=0;

  handle.addEventListener('pointerdown', (ev) => { resizing=true; sx=ev.clientX; sy=ev.clientY; sw=el.offsetWidth; sh=el.offsetHeight; handle.setPointerCapture(ev.pointerId); });

  handle.addEventListener('pointermove', (ev) => {

    if(!resizing) return;

    const dx = (ev.clientX - sx)/zoom, dy = (ev.clientY - sy)/zoom;

    el.style.width  = Math.max(40, snap(sw + dx)) + 'px';

    el.style.height = Math.max(40, snap(sh + dy)) + 'px';

  });

  handle.addEventListener('pointerup', () => resizing=false);

  // تحديد

  el.addEventListener('focus', () => selectNode(el));

  canvas.appendChild(el);

  selectNode(el);

}

function selectNode(el){

  if(selected) selected.classList.remove('is-selected');

  selected = el;

  if(!el) return;

  el.classList.add('is-selected');

  const inner = el.firstChild;

  propText.value = inner.tagName==='IMG' ? '' : (inner.textContent || '');

  propFont.value = parseInt(getComputedStyle(inner).fontSize) || 18;

  propColor.value = toHex(getComputedStyle(inner).color) || '#e5e7eb';

  propBg.value = toHex(getComputedStyle(el).backgroundColor) || '#111827';

  propRadius.value = parseInt(getComputedStyle(el).borderRadius) || 8;

  propLink.value = inner.tagName==='A' ? (inner.getAttribute('href') || '') : '';

  propText.oninput   = () => { if(inner.tagName!=='IMG') inner.textContent = propText.value; };

  propFont.oninput   = () => { inner.style.fontSize = propFont.value + 'px'; };

  propColor.oninput  = () => { inner.style.color = propColor.value; };

  propBg.oninput     = () => { el.style.background = propBg.value; };

  propRadius.oninput = () => { el.style.borderRadius = propRadius.value + 'px'; };

  propLink.oninput   = () => { if(inner.tagName==='A'){ inner.href = propLink.value || '#'; } };

}

function toHex(rgb){

  if(!rgb) return '#000000';

  const m = rgb.match(/\d+/g); if(!m) return '#000000';

  return '#'+m.slice(0,3).map(n => ('0'+parseInt(n,10).toString(16)).slice(-2)).join('');

}

function snap(v){ const g=20; return Math.round(v / g) * g; }

// تكبير/تصغير

document.getElementById('nocode-zoom-in').addEventListener('click', () => setZoom(zoom + 0.1));

document.getElementById('nocode-zoom-out').addEventListener('click', () => setZoom(Math.max(0.3, zoom - 0.1)));

function setZoom(z){

  zoom = z;

  document.querySelector('.workspace').style.transform = `scale(${zoom})`;

}

// خلفية اللوحة

document.getElementById('canvas-bg').addEventListener('input', (e) => {

  document.querySelector('.workspace-wrap').style.background = e.target.value;

});

// حفظ/تصدير (بدون كود)

document.getElementById('save-nocode').addEventListener('click', () => {

  localStorage.setItem('project-nocode', canvas.innerHTML);

  alert('تم الحفظ محليًا.');

});

document.getElementById('export-nocode').addEventListener('click', () => {

  // تحويل محتوى canvas إلى صفحة HTML بسيطة

  const inner = canvas.innerHTML;

  const html = `

<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>

<title>مشروعي</title><style>body{margin:0;background:#0b1220;color:#e5e7eb;font-family:system-ui,Arial} .container{max-width:1100px;margin:0 auto;padding:24px}</style></head>

<body><div class="container">${inner}</div></body></html>`;

  download('project-nocode.html', html, 'text/html');

});

// أداة تنزيل عامة

function download(name, content, type){

  const blob = new Blob([content], { type });

  const a = document.createElement('a');

  a.href = URL.createObjectURL(blob);

  a.download = name;

  a.click();

}

// اختصارات بسيطة

document.addEventListener('keydown', (e) => {

  if(e.key==='Delete' && selected){ selected.remove(); selected=null; }

});

// روابط التنقل العلوية

document.querySelectorAll('.nav__link').forEach(a => {

  a.addEventListener('click', (e) => {

    e.preventDefault();

    const v = a.dataset.view;

    showView(v);

  });

});